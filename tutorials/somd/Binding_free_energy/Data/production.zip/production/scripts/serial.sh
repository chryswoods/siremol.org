#!/bin/bash
# Warning! Script executing simulations serially. Very slow and avoid doing this at ALL costs!
# You may have to explicitly set your OpenMMplugins directory!

lamvals=( 0.000, 0.125, 0.250, 0.375, 0.500, 0.625, 0.750, 0.875, 1.000 )

#export OPENMM_PLUGIN_DIR=/home/username/sire.app/lib/plugins/

for lam in "${lamvals[@]}"
do

echo "lambda is: " $lam

mkdir lambda-$lam
cd lambda-$lam
somd-freenrg -C ../../input/sim.cfg -l $lam -p CUDA
cd ..

done
